#!/usr/bin/env python3
"""
make_cadec_csv.py  –  merge all CADEC .ann files into a CSV
Output columns: concept, phrase
"""

import argparse
import csv
import re
from pathlib import Path
from typing import List, Tuple

# ---------------- helpers ---------------------------------------------- #
_CONCEPT_RE = re.compile(r"\|\s*([^|]+?)\s*\|")      # capture concept names

def parse_ann_line(text: str) -> List[Tuple[str, str]]:
    """Return [(concept, phrase), …] for one annotation line (or [])."""
    if not text.startswith("TT"):       # ignore TL / TR etc.
        return []
    parts = text.rstrip("\n").split("\t")
    if len(parts) < 3:
        return []
    code_field, phrase = parts[1], parts[2]
    concepts = _CONCEPT_RE.findall(code_field)
    return [(c.strip(), phrase.strip()) for c in concepts]

# ---------------- robust file reader ------------------------------------ #
def iter_ann_lines(path: Path):
    """
    Yield decoded lines from *path*, trying UTF-8 first, then Latin-1.
    Works even if the file has mixed encodings (rare but possible).
    """
    with path.open("rb") as fh:                       # 1) read raw bytes
        for raw in fh:
            try:                                      # 2) UTF-8?
                yield raw.decode("utf-8")
            except UnicodeDecodeError:                # 3) fall back
                yield raw.decode("latin-1", errors="replace")

# ---------------- traversal & CSV writer -------------------------------- #
def collect_rows(root: Path) -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    for ann_path in root.rglob("*.ann"):              # recursive, case-ins.
        for line in iter_ann_lines(ann_path):
            rows.extend(parse_ann_line(line))
    for ann_path in root.rglob("*.ANN"):              # upper-case suffix
        for line in iter_ann_lines(ann_path):
            rows.extend(parse_ann_line(line))
    return rows

def write_csv(rows: List[Tuple[str, str]], out_csv: Path) -> None:
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with out_csv.open("w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows([("concept", "phrase"), *rows])

# ---------------- main -------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description="Convert CADEC .ann → CSV")
    ap.add_argument("input_dir", type=Path, help="Folder that holds CADEC")
    ap.add_argument("output_csv", type=Path, help="Destination CSV")
    args = ap.parse_args()

    rows = collect_rows(args.input_dir)
    write_csv(rows, args.output_csv)
    print(f"✓ Wrote {len(rows):,} rows to {args.output_csv}")

if __name__ == "__main__":
    main()
